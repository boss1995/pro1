package com.cg.modal;

import javax.validation.constraints.Pattern;

public class LoginForm {

	@Pattern(regexp="[A-Z a-z 0-9]{5,15}",message="Invalid Username")
	private String username;
	
	@Pattern(regexp="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#&$%]).{5,15})", message="Invalid password")
	 private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
}
