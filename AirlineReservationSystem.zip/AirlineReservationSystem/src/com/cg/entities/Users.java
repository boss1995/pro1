//create table user(userId number primaryKey,firstname  VARCHAR2(20),lastname VARCHAR2(20),mobileNo VARCHAR2(20),emailid VARCHAR2(20),dofb VARCHAR2(20),address VARCHAR2(20),username VARCHAR2(20),password VARCHAR2(20));
package com.cg.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "UserInfo")
public class Users {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="seq")
	@SequenceGenerator(name="seq", sequenceName="user_info_id_seq", allocationSize=1)
	@Column(name="user_id")
	private int userId;
	
	@Column(name="first_name")
	@Pattern(regexp="[A-Za-z]{3,15}",message="Name should range between 3-15 characters")
	private String firstname;
	
	@Column(name="last_name")
	@Pattern(regexp="[A-Za-z]{3,15}",message="Name should range between 3-15 characters")
	private String lastname;
	
	@Column(name="mobile_no")
	@Pattern(regexp="[0-9]{10}",message="Mobile Number should be 10 digit long.")
	private String mobileNo;
	
	@Column(name="email_id")
	@Pattern(regexp="^[a-zA-Z0-9_!#$%&�*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$",message="Invalid Email Address")
	private String emailId;
	
	@Column(name="DOB")
	@NotNull(message="Please enter your Date of Birth")
	@DateTimeFormat(pattern="dd-MM-yyyy")
	@Temporal(TemporalType.DATE)
	private Date dob;

	@Column(name="address")
	@Pattern(regexp="[A-Za-z]{3,15}",message="Name should range between 3-15 characters")
	private String address;

	@Column(name="username")
	@Pattern(regexp="[A-Z a-z 0-9]{5,15}",message="User Name must be 5 to 15 characters.\nAtleast 1 uppercase, 1 lower case and 1 number.")
	private String username;

	@Column(name="password")
	@Pattern(regexp="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#&$%]).{5,15})", message="Password must be between 6 to 15 characters.\nAtleast 1 uppercase, 1 lowercase, 1 special symbol and a special character'@#$&%'")
	 private String password;
	
	//getter and setter
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}	
	public Date getDob() {
		return dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	 

}
