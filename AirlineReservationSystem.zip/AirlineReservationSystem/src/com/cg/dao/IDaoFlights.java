package com.cg.dao;

import java.util.List;

import com.cg.entities.Booking;
import com.cg.entities.Flight;
import com.cg.entities.Users;
import com.cg.exception.QueryException;

public interface IDaoFlights {
	public Users addUser(Users user);
	public List<Flight> getAllFlights(String dc,String ac,String dd) throws QueryException;
	public Users getUsers(String a, String b) throws QueryException;
	public List<Flight> getFlightlist(String flightNo);
	public Booking addBooking(Booking booking);
	public Users getUserInfo(int userId);
	public Users updateUser(Users u2);
	public Booking getBooking(int book);
	public boolean deleteBooking(int bookingId);
	

	public Booking addBook(String flightId,int seats);
	public Flight getFare(String fId);
}
