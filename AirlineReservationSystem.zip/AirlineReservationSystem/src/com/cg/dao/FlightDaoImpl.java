package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Booking;
import com.cg.entities.Flight;
import com.cg.entities.Users;
import com.cg.exception.QueryException;
@Repository
public class FlightDaoImpl implements IDaoFlights{
	@PersistenceContext
	EntityManager manager;
	

	public EntityManager getManager() {
		return manager;
	}


	public void setManager(EntityManager manager) {
		this.manager = manager;
	}


	@Override
	public Users addUser(Users user) {
		// TODO Auto-generated method stub
		manager.persist(user);
		return user;
	}


	@Override
	public List<Flight> getAllFlights(String dc, String ac, String dd) throws QueryException {
		// TODO Auto-generated method stub
		
		List<Flight> empList;
		try {
			String query="select eld from Flight eld where eld.depCity=:d and eld.arrCity=:a and eld.depDate=:t";
			TypedQuery<Flight> tquery=manager.createQuery(query, Flight.class);
			tquery.setParameter("d", dc);
			tquery.setParameter("a", ac);
			tquery.setParameter("t", dd);
			empList=tquery.getResultList();
		
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new QueryException("No Flights Available");
		}
		return empList;
	}


	@Override
	public Users getUsers(String a, String b) throws QueryException{
		// TODO Auto-generated method stub
		Users user;
		try {
			String query="select u from Users u where u.username=:n and u.password=:p";
			TypedQuery<Users> tquery=manager.createQuery(query, Users.class);
			tquery.setParameter("n", a);
			tquery.setParameter("p", b);
			 user=tquery.getSingleResult();
			
		} catch (Exception e) {
			throw new QueryException("Invalid User");
			
		}
		return user;
	}


	@Override
	public List<Flight> getFlightlist(String flightNo) {
		String str = "Select flight from Flight flight where flight.flightNo=:f";
		TypedQuery<Flight> tquery = manager.createQuery(str, Flight.class);
		tquery.setParameter("f", flightNo);
		List<Flight> list = tquery.getResultList();
		return list;
	}


	@Override
	public Booking addBooking(Booking booking) {
		manager.persist(booking);
		return booking;
	}


	@Override
	public Users getUserInfo(int userId) {
		Users u1=manager.find(Users.class,userId);
		return u1;
		
	}


	@Override
	public Users updateUser(Users user) {
		Users e1=manager.find(Users.class, user.getUserId());		
		e1.setFirstname(user.getFirstname());
		e1.setLastname(user.getLastname());
		e1.setEmailId(user.getEmailId());
		e1.setMobileNo(user.getMobileNo());
		e1.setDob(user.getDob());	
		e1.setAddress(user.getAddress());
		e1.setUsername(user.getUsername());
		e1.setPassword(user.getPassword());
		return user;
		
	}
	
	
	@Override
	public Booking getBooking(int book) {
		Booking booking=manager.find(Booking.class, book);
		return booking;
	}

	@Override
	public boolean deleteBooking(int bookingId) {
		// TODO Auto-generated method stub
				Query query=manager.createQuery("delete from Booking e where e.bookingId= "+bookingId);
				query.executeUpdate();
				return true;
			}


	@Override
	public Booking addBook(String flightId, int seats) {
		// TODO Auto-generated method stub
		Flight c1=manager.find(Flight.class,flightId);
		int seat=c1.getEconomySeats();
		seat=seat-seats;
		c1.setEconomySeats(seat);
		return null;
	}


	@Override
	public Flight getFare(String fId) {
		String query="select u from Flight u where u.flightNo=:n";
		TypedQuery<Flight> tquery=manager.createQuery(query, Flight.class);
		tquery.setParameter("n", fId);
		
		Flight fli=tquery.getSingleResult();
		return fli;
	}
	
	

}
